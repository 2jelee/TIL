import React from 'react';
import {useSelector} from "react-redux";

function Home() {
    // Redux store 가져오기
    // let a = useSelector((state) => {return state}) // Redux store에 있던 모든 state가 이 자리에 남는다.
    // console.log("store:"+ a);

    return (
        <>
            <h1>🏠감자도리 메인페이지🏡</h1>
        </>
    );
}

export default Home;


//rsf