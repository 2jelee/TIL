import { useNavigate } from 'react-router';
import { useDispatch } from 'react-redux';
import { useForm } from 'react-hook-form';
// import { ErrorMessage } from '@hookform/error-message';

import { loginUser } from '../store/Users';
import { setRefreshToken } from '../store/Cookie';
import { SET_TOKEN } from '../store/Auth';


function Login() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    // useForm 사용을 위한 선언
    const { register, setValue, formState: { errors }, handleSubmit } = useForm();

    // submit 이후 동작할 코드
    // 백으로 유저 정보 전달
    const onValid = async ({ user_id, password }) => {
        const response = await loginUser({ user_id, password });

        if (response.status) {
            // 쿠키에 Refresh Token, store에 Access Token 저장
            setRefreshToken(response.text.refresh_token);
            dispatch(SET_TOKEN(response.text.access_token));

            return navigate("/");
        } else {
            console.log(response.text);
        }
        // input 태그 값 비워주는 코드
        setValue("password", "");
    };

    return (
        <>
            <div>
                <div>
                    <div>
                        <h2>LOGIN</h2>
                    </div>
                    <form onSubmit={handleSubmit(onValid)}>
                        <div>
                            <div>
                                <label htmlFor="user_id">
                                    User ID
                                </label>
                                <input
                                    {...register("user_id", {required: "Please Enter Your ID"})}
                                    type="text"
                                    placeholder="ID"
                                />
                                {/*<ErrorMessage*/}
                                {/*    name="userid"*/}
                                {/*    errors={errors}*/}
                                {/*    render={( { message }) =>*/}
                                {/*        <p className="text-sm font-medium text-rose-500">*/}
                                {/*            { message }*/}
                                {/*        </p>*/}
                                {/*    }*/}
                                {/*/>*/}
                            </div>
                            <div>
                                <label htmlFor="password">
                                    Password
                                </label>
                                <input
                                    {...register("password", {required: "Please Enter Your Password"})}
                                    type="password"
                                    placeholder="PASSWORD"
                                />
                                {/*<ErrorMessage*/}
                                {/*    name="userid"*/}
                                {/*    errors={errors}*/}
                                {/*    render={( { message }) =>*/}
                                {/*        <p className="text-sm font-medium text-rose-500">*/}
                                {/*            { message }*/}
                                {/*        </p>*/}
                                {/*    }*/}
                                {/*/>*/}
                            </div>
                        </div>
                        <div>
                            <button
                                type="submit"
                            >
                                Sign in
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}

export default Login;