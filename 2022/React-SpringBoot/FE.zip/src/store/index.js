import { configureStore } from '@reduxjs/toolkit';
import tokenReducer from './Auth';

// 위에서 선언한 reducer를 사용하기 위해 configureStore 를 선언해 준다.

export default configureStore({
    reducer: {
        ACCESS_TOKEN: tokenReducer,
    },
});