import React from 'react';
import './App.css';
import { Routes, Route, Link } from 'react-router-dom';
import Login from "./store/Login";
import Home from "./routes/Home";


function App() {
    // mount, update 시 해당 코드 실행
    // useEffect 내에 있는 코드는 html 랜더링 후에 동작한다. -어려운 연산 / 서버에서 데이터 가져오는 작업 / 타이머 장착
    // useEffect(()=>{
    //     console.log("hi");
    //     // login.onSlientRefresh;
    //     // console.log(login.onSlientRefresh);
    //     let a = setTimeout(()=>{ }, 2000)
    // // }, []) //dependencies : useEffect 실행조건을 넣음.
    //     return ()=>{
    //         // useEffect 동작 전에 실행되는 return()=>{}
    //         // ex. 기존 데이터 요청을 제거해줘라.
    //         clearTimeout();
    //     }
    // }, []) //dependencies : useEffect 실행조건을 넣음.

    return (
      <>
          <Link to="/">HOME</Link>&nbsp;
          <Link to="/login">LOGIN</Link>

          <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              {/* 404 page */}
              <Route path="*" element={<div> 없는 페이지 </div>} />
          </Routes>

          {/*<div>*/}
          {/*    BE test : {test}*/}
          {/*</div>*/}
      </>
  );
}

export default App;
