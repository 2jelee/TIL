package com.example.projects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
